public class SecureInfo 

{ 
    private int SSN { get; set; } 

    private int CreditCardInformation { get; set; } 


    public SecureInfo(int sSN, int creditCardInformation)
    {
        SSN = sSN;
        CreditCardInformation = creditCardInformation;
    }

}

 