public class WelcomeSignUp 

{ 

    public bool OwnOrRent { get; set; } 

  

    public void SignUpInfo() 

    { 

        Console.WriteLine("Welcome! Are you an owner or renter?"); 

        OwnOrRent = Convert.ToBoolean(Console.ReadLine()); 

    } 

} 

  

