public class SecureInfo 

{ 

    public int SSN { get; set; } 

    public int CreditCardInformation { get; set; } 

} 

 

 